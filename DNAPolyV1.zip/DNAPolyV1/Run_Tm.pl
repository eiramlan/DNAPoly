#!/usr/bin/perl

#use strict;
#use warnings;
## input need : 1)SequenceTILB.txt
#Final output Filename: /Users/huisan/Desktop/Graph_theory/CompletedSortTmDecreasingOrder.txt
#Main 1st Step: : InitiateDNAWithSelfHybridize.pl 

use Cwd;
use Cwd qw();
# Extract current working directory and pass to the script
my $CurrentDirectory = Cwd::cwd();
my $path = $CurrentDirectory;
my $originalpath = $path;

#my $SquareType = "BEWI";

open (READ_SQUARETYPE, "${path}/SquareType.txt") || die "couldn't open the file (${path}/SquareType.txt)!";  
#open THEFILE, "<filename.txt";
my $first_line = <READ_SQUARETYPE>;
my @extractWithoutNewline = split(/\n/, $first_line);
close READ_SQUARETYPE;
my $SquareType = $extractWithoutNewline[0];
print "SquareType= $SquareType---\n";


#because i use >> append OutUnaFoldCompleted.txt, therefore need to delete if exist
my $file = "${path}/OutUnaFoldCompleted.txt";
my $removed = unlink($file);
#print "Removed $removed file(s).\n";

### split all sequences in SequenceTILB.txt into different files for each line, 1.txt, 2.txt...14.txt
open (INSEQ, "${path}/Sequence${SquareType}.txt") or die;
my $SeqNo = 1;
# go through the file line by line    
while (my $line = <INSEQ>)  {
    # split the current line on new line
    my @eachline = split(/\n/, $line);
	open (SPLITSEQ, ">${path}/unafold-3.8/$SeqNo.txt");
    # print the first column of the line
    print SPLITSEQ "$eachline[0]\n";
    #print READCHECK "$eachline[0]\n";
    close SPLITSEQ;
     #print "$SeqNo\n";
    $SeqNo++;
   
}

# close the filehandle and exit
close INSEQ;



#print "TotalSeq = $SeqNo-1\n";


## with self hybridization eg. 1-1, 2-2 homodimer
## only differ in line 40-41 compared with without self-hybridization
open (OUTPUTMATCHINGPAIR, ">${path}/MatchingPair.txt") || die "couldn't output to file (MatchingPairTm)!";

## delete OutUnaFoldCompleted.txt if file exists
my $file2 = "${path}/unafold-3.8/OutUnaFoldCompleted.txt";
my $removed2 = unlink($file2);
#print "Removed $removed2 file(s).\n";

my $RemovedOutunafold = unlink("${path}/OutUnaFoldCompleted.txt");
#print "Removed $RemovedOutunafold file(s).\n";

## change directory to unafold so that unafld can run
chdir("${path}/unafold-3.8/") or die "cannot change: $!\n";

#foreach seqNO, run melt.pl against the remaining seq, to see which seq will melt/denature 1st
for (my $a=1; $a< $SeqNo; $a++) {
	for (my $b=$a; $b< $SeqNo; $b++) {
	system "chmod", "u+x", "${path}/";
	system ("melt.pl --NA DNA --sodium 1 --C 0.00001 $a.txt $b.txt >> OutUnaFoldCompleted.txt");
	#print READCHECK "melt.pl --NA DNA --sodium 1 --C 0.00001 $a.txt $b.txt >> OutUnaFoldCompleted.txt\n";
	#print "$a - $b\n";
	print OUTPUTMATCHINGPAIR "$a	$b\n";
	}
}
close OUTPUTMATCHINGPAIR;
########### END : foreach seqNO, run melt.pl against the remaining seq, to see which seq will melt/denature 1st




#print "path3 = $path\n";
my $FilteredUnaFold = "${path}/Filtered_UnaFold.txt";



## to make a copy of the  original unafold output before extracting the Tm; for checking purposes
system ("cp -i ${path}/unafold-3.8/OutUnaFoldCompleted.txt ${path}/");
#system ("mv /Users/huisan/Desktop/Graph_theory/OutUnaFoldCompleted.txt /Users/huisan/Desktop/Graph_theory/OriginalOutputUnaFold");
##### END 

### extracting the every 4th line,delete the rest of lines and only keep the every 4th line in the original files. Therefore need to backup the files ("to make a copy of the  original unafold output..")

## Original output
#### dG		dH			dS	 Tm
####-21.6	-117.6	-309.5	77.7

## Extracted output
####-21.6	-117.6	-309.5	77.7
system ("awk 'NR % 3 == 0' ${path}/OutUnaFoldCompleted.txt > ${path}/Filtered_UnaFold.txt");


##For checking purposes, see if the total lines in MatchingPair.txt is = as total lines of extracted Tm

my $Seq_MatchingPair = "${path}/MatchingPair.txt";
my $countMatchigPairLine = 0;
my @arrfilename;
my $recordm;

open (READMATCH, "$Seq_MatchingPair") || die "couldn't open the file ($Seq_MatchingPair)!";
while ($recordm = <READMATCH>){
 $arrfilename[$countMatchigPairLine] = substr($recordm,0,length($recordm)-1);
 $countMatchigPairLine++; 
}
close(READMATCH);
#print "Total Lines in Matching Pairs = $countMatchigPairLine\n";



my $countTmLine = 0;
my @arrfilenameTm;
my $record;

open (READTM, "$FilteredUnaFold") || die "couldn't open the file ($FilteredUnaFold)!";
while ($record = <READTM>){
 $arrfilenameTm[$countTmLine] = substr($record,0,length($record)-1);
 $countTmLine++; 
}
close(READTM);
#print "Total Lines in Tm = $countTmLine\n";

my $countMatchigPairLin;

if ($countMatchigPairLine == $countTmLine) {
#print "$countMatchigPairLine = $countMatchigPairLine\n";
}

else {
#print "Error in matching pairs and extracted Tm lines, Please check back original file Filename: OutUnaFoldCompleted.txt\n";
}




## delete all temporary files generated during unafold
for (my $s=1; $s< $SeqNo; $s++) {
#unlink glob ("${path}/unafold-3.8/$s.txt*");
}

########## END: checking purpose










