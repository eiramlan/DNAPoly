#!/usr/bin/perl -w


use Cwd;
use Cwd qw();
# Extract current working directory and pass to the script
my $CurrentDirectory = Cwd::cwd();
my $path = $CurrentDirectory;
my $originalpath = $path;

open (READCHECK, ">>${path}/check.txt");
    # print the first column of the line
    
    
chdir("${path}/unafold-3.8/") or die "cannot change: $!\n";

my $CurrentDirectory = Cwd::cwd();
my $path = $CurrentDirectory;
print READCHECK "path2 = ${path}\n";
#foreach seqNO, run melt.pl against the remaining seq, to see which seq will melt/denature 1st
for (my $a=1; $a< 14; $a++) {
	for (my $b=$a; $b< 14; $b++) {
	system ("melt.pl --NA DNA --sodium 1 --C 0.00001 $a.txt $b.txt >> OutUnaFoldCompleted.txt");
	print READCHECK "melt.pl --NA DNA --sodium 1 --C 0.00001 $a.txt $b.txt >> OutUnaFoldCompleted.txt\n";
	#print "$a - $b\n";
	print OUTPUTMATCHINGPAIR "$a	$b\n";
	}
}
close OUTPUTMATCHINGPAIR;