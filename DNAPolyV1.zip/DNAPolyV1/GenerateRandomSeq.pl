#!/usr/bin/perl
# Generate random DNA
#  using a random number generator to randomly select bases

use strict;
use warnings;

use Cwd;
use Cwd qw();
# Extract current working directory and pass to the script
my $CurrentDirectory = Cwd::cwd();
my $path = $CurrentDirectory;

my @Length = @_;
my $ColumnSeqNo = @_;
my @SeqNo = @_;

open (READ_SQUARETYPE, "${path}/SquareType.txt") || die "couldn't open the file (${path}/SquareType.txt)!";  
#open THEFILE, "<filename.txt";
my $first_line = <READ_SQUARETYPE>;
my @extractWithoutNewline = split(/\n/, $first_line);
close READ_SQUARETYPE;
my $SquareType = $extractWithoutNewline[0];
print "SquareType= --$SquareType---\n";




open (READ_DEFINE, "${path}/${SquareType}DefineSeq.txt") || die "couldn't open the file (${path}/${SquareType}DefineSeq.txt)!";
while (my $DefineSeq = <READ_DEFINE>)  {
my @Column = split(/\t/,$DefineSeq);
my $ColumnLength = $Column[1];
my $ColumnSeqNo = $Column[0];
push(@Length,$ColumnLength);
push(@SeqNo,$ColumnSeqNo);
}
close READ_DEFINE;

my @sortedLength = sort { $a <=> $b } @Length;
my @sortedSeqNo = sort { $a <=> $b } @SeqNo;
my $MaxLengthDefineSeq = $sortedLength[-1];
my $MaxSeqNo = $sortedSeqNo[-1];

my $size_of_set = $MaxSeqNo;
my $maximum_length = $MaxLengthDefineSeq;
my $minimum_length = $MaxLengthDefineSeq;

# An array, initialized to the empty list, to store the DNA in
my @random_DNA = (  );

# Seed the random number generator.
# time|$$ combines the current time with the current process id
srand(time|$$);

# And here's the subroutine call to do the real work
@random_DNA = make_random_DNA_set( $minimum_length, $maximum_length, $size_of_set );

open (OUTPUTSEQ, ">${path}/RandomSeq.txt");
foreach my $dna (@random_DNA) {
    print OUTPUTSEQ "$dna\n";
}

close OUTPUTSEQ;

exit;

################################################################################
# Subroutines
################################################################################
#   Accept parameters setting the maximum and minimum length of
#     each string of DNA, and the number of DNA strings to make

sub make_random_DNA_set {
    my($minimum_length, $maximum_length, $size_of_set) = @_;
    my $length;
    my $dna;
    my @set;
    for (my $i = 0; $i < $size_of_set ; ++$i) {
        $length = randomlength ($minimum_length, $maximum_length);
        $dna = make_random_DNA ( $length );
        push( @set, $dna );
    }
return @set;
}



# randomlength
# A subroutine that will pick a random number from
# $minlength to $maxlength, inclusive.

sub randomlength {

    # Collect arguments, declare variables
    my($minlength, $maxlength) = @_;

    # Calculate and return a random number within the
    #  desired interval.
    # Notice how we need to add one to make the endpoints inclusive,
    #  and how we first subtract, then add back, $minlength to
    #  get the random number in the correct interval.
    return ( int(rand($maxlength - $minlength + 1)) + $minlength );
}


# Make a string of random DNA of specified length.
sub make_random_DNA {
    my($length) = @_;
    my $dna;
    for (my $i=0 ; $i < $length ; ++$i) {
        $dna .= randomnucleotide(  );
    }
    return $dna;
}


# Select at random one of the four nucleotides
sub randomnucleotide {
    my(@nucleotides) = ('a', 'c', 'g', 't');
    return randomelement(@nucleotides);
}


# randomly select an element from an array

sub randomelement {
    my(@array) = @_;
    return $array[rand @array];
}



