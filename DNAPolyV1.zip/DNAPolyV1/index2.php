<html>
    <body>
        <?php
        
    $MinGC = $_POST['mingc'];
	$MaxGC = $_POST['maxgc'];
	$Tm = $_POST['meltingtemp'];
	$Prob = $_POST['probability'];
	$Uptake = $_POST['uptakerate'];
	$SquareType = $_POST['square'];
	$Email = $_POST['email'];
        
     echo "<p><font face='Arial'>MinGC: ".$MinGC. "</font></p>"; 
      echo "<p><font face='Arial'>MaxGC: ".$MaxGC. "</font></p>"; 
       echo "<p><font face='Arial'>Tm: ".$Tm. "</font></p>"; 
        echo "<p><font face='Arial'>Prob: ".$Prob. "</font></p>"; 
         echo "<p><font face='Arial'>Uptake: ".$Uptake. "</font></p>"; 
         echo "<p><font face='Arial'>Rectangular: ".$SquareType. "</font></p>"; 
          echo "<p><font face='Arial'>Email: ".$Email. "</font></p>"; 
          
      	
		
		
			file_put_contents("/Applications/MAMP/htdocs/MinCG.txt", ($MinGC / 100));
			file_put_contents("/Applications/MAMP/htdocs/MaxCG.txt", ($MaxGC / 100));
			file_put_contents("/Applications/MAMP/htdocs/MeltingTemperature.txt", $Tm);
			file_put_contents("/Applications/MAMP/htdocs/ThresholdProbabilityEnergy.txt", $Prob);
			file_put_contents("/Applications/MAMP/htdocs/DNAUptakeRate.txt", $Uptake);
			file_put_contents("/Applications/MAMP/htdocs/SquareType.txt", $SquareType);
			
			
			function print_procedure ($arg) {
               echo shell_exec("/Applications/MAMP/htdocs/Main_RunDNATetris.tcl");
             #  echo shell_exec("/Applications/MAMP/htdocs/index3.pl");
            }
			$script_name='Main_RunDNATetris.tcl';
			#$script_name='index3.pl';
			#passthru("/Applications/MAMP/htdocs/Main_RunDNATetris.tcl");
			#$output=shell_exec("/Applications/MAMP/htdocs/Main_RunDNATetris.tcl");
			#echo $output;
			#print_procedure($script_name);
            echo "<table border='1' cellpadding='1' cellspacing='2'><tr><th><font face='Arial'>SequenceNo</th><th><font face='Arial'>DNA Strands</th><th><font face='Arial'>No of Iteration</th><th><font face='Arial'>Thermodynamics Free Energy(AllSub, kcal/mol)<th><font face='Arial'>Thermodynamics Free Energy(DuplexFold, kcal/mol)</th><th><font face='Arial'>Percentage of CG content</th></font></tr>";
	
            	
        ?>
    </body>
</html>