#!/usr/bin/perl

my $filename = "foo";
`echo $filename > $filename`;