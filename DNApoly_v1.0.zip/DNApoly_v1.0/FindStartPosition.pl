#!/usr/bin/perl
use strict;
use warnings;

use Cwd qw();
my $CurrentDirectory = Cwd::cwd();
my $path = $CurrentDirectory;
my $FBS = 6;
my $query_file = "${path}/query1.txt";
my $target_file = "${path}/target1.txt";
my $recordq;
my @arrfilenameq;
my $q=0;
my $recordt;
my @arrfilenamet;
my $t=0;
my $i=0;
#my $j=0;
my $target;
my @values_target = @_;
my @rev_complem_query2 = @_;

open (READQUERY, "$query_file") || die "couldn't open the file ($query_file)!";
while ($recordq = <READQUERY>){
 $arrfilenameq[$q] = substr($recordq,0,length($recordq)-1);
 $q++;
}
close(READQUERY);


open (READTARGET, "$target_file") || die "couldn't open the file ($target_file)!";
while ($recordt = <READTARGET>){
 $arrfilenamet[$t] = substr($recordt,0,length($recordt)-1);
 $t++;
}
close(READTARGET);

open (QUERY_SEQ, ">${path}/query");
open (TARGET_SEQ, ">${path}/target");
open (POS_QUERY, ">${path}/position_query");
open (POS_TARGET, ">${path}/position_target");


#search the beginner starting sequence within minimum 2 nucleotides
for ($i=0; $i<scalar @arrfilenameq; $i++) {
my $rev_query;
#my @rev_complem_query2;
my $rev_complem_query;
my $query = $arrfilenameq[$i];

$rev_query = reverse($query);
$rev_complem_query = complement($rev_query) ;

	for (my $j=0; $j<scalar @arrfilenamet; $j++) {
	my $target = $arrfilenamet[$j];
	
	my @values_target = split(//,$target);
	print "1. target = $target\nvalues_target= @values_target\n";
	my $len_target = scalar(@values_target);
	print "2. len_target = $len_target\n";
	my @rev_complem_query2 = split(//,$rev_complem_query);
	print "3. rev_complem_query= $rev_complem_query\n";
	print "4. rev_complem_query2 = @rev_complem_query2\n";
	my $len_query = scalar (@rev_complem_query2);
	print "5. len_query=$len_query\n";
	
	# do tmr change the zero in ($query,0,2) into variable
	
	for (my $position_query=0; $position_query<$len_query-2; $position_query++) {
	my @start_target = ();
	my @start_query = ();
	
	print QUERY_SEQ "$rev_complem_query\n";
	print TARGET_SEQ "$target\n";
	print POS_QUERY "$position_query\n"; #start of query position from left to right, 1 nt at a time

		for (my $position=0; $position < scalar (@values_target) ; $position++) {
        if(substr($rev_complem_query,$position_query,$FBS) eq substr($target,$position,$FBS)) {
            push (@start_target,$position);  
        }
    	}
	print POS_TARGET "@start_target\n";
}
}
}
close QUERY_SEQ ;
close TARGET_SEQ ;
close POS_QUERY ;
close POS_TARGET ;

sub complement {
    $_[0] =~ y/CGATcgat/GCTAgcta/;
    return $_[0];
}
