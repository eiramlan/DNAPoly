<html>

<!-- CSS Code -->
<style type="text/css" scoped>
table.gridtable {
	font-family: verdana,arial,sans-serif;
	font-size:15px;
	color:#333333;
	border-width: 1px;
	border-color: #666666;
	border-collapse: collapse;
}
table.gridtable th {
	border-width: 1px;
	padding: 4px;
	border-style: solid;
	border-color: #666666;
	background-color: #58FAF4;
}
table.gridtable td {
	border-width: 1px;
	padding: 4px;
	border-style: solid;
	border-color: #666666;
	background-color: #ffffff;
}
</style>

<?php
function get_rows() {
	$file=fopen("Summary_AfterOptimized_Seq.txt",'r');
	while($line = fgets($file)){//while we can still read the file
		$line=trim($line);//remove the line endings and extra white-spaces at start and end
		list($title,$author,$started,$author2) = explode('	',$line);//you get an array of 4 per line, first item is author, etc...
		echo "<tr><td>$title</td><td>$author</td><td>$started</td><td>$author2</td></tr>\n";//use the \n to clean up the source a code a bit to make it readable
	}
return true;
}
?>

//everything is the regular html stuff.
<table class="gridtable">
    <tr>
        <th>No</th>
        <th>DNA Strands</th>
        <th>Iteration</th>
        <th>GC Percentage(x100)</th>
    </tr>
<?php get_rows(); ?>
</table>
</div>
</html>
