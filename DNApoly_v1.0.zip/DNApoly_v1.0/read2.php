<html>
<?php
echo file_get_contents("/Applications/MAMP/htdocs/interpret.txt");
?>
</html>

