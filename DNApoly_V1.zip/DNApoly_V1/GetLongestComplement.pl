#!/usr/bin/perl
use strict;
use warnings;


#better version od second_complement2.pl because it doesnot output redundancy/repeated sequence
#second_complem.pl
#CCCATTTGATGATTCGCGTTAGTGGTTCCTACGACAAGATGCAGAATCCGTCGAT : CTGCCGACATCAGGTCAGGCTCCGAACAGTAGATGGTGGAAGAGTATTCCGCTCGATGCTTATCGGTATCCTGGA 	 Target match : CGACA ; 4 ; 8 	 Query: 31 ; 35 	  ori query = ATCGACGGATTCTGCATCTTGTCGTAGGAACCACTAACGCGAATCATCAAATGGG
#cycle_within_same_querypos = 5	max = 5
#CCCATTTGATGATTCGCGTTAGTGGTTCCTACGACAAGATGCAGAATCCGTCGAT : CTGCCGACATCAGGTCAGGCTCCGAACAGTAGATGGTGGAAGAGTATTCCGCTCGATGCTTATCGGTATCCTGGA 	 Target match : AGATG ; 30 ; 34 	 Query: 36 ; 40 	  ori query = ATCGACGGATTCTGCATCTTGTCGTAGGAACCACTAACGCGAATCATCAAATGGG
#cycle_within_same_querypos = 5 5	max = 5
#CCCATTTGATGATTCGCGTTAGTGGTTCCTACGACAAGATGCAGAATCCGTCGAT : CTGCCGACATCAGGTCAGGCTCCGAACAGTAGATGGTGGAAGAGTATTCCGCTCGATGCTTATCGGTATCCTGGA 	 Target match : GATGC ; 54 ; 58 	 Query: 37 ; 41 	  ori query = ATCGACGGATTCTGCATCTTGTCGTAGGAACCACTAACGCGAATCATCAAATGGG
#cycle_within_same_querypos = 5 5 5	max = 5
#CCCATTTGATGATTCGCGTTAGTGGTTCCTACGACAAGATGCAGAATCCGTCGAT : CTGCCGACATCAGGTCAGGCTCCGAACAGTAGATGGTGGAAGAGTATTCCGCTCGATGCTTATCGGTATCCTGGA 	 Target match : TCGAT ; 52 ; 56 	 Query: 50 ; 54 	  ori query = ATCGACGGATTCTGCATCTTGTCGTAGGAACCACTAACGCGAATCATCAAATGGG
#cycle_within_same_querypos = 5 5 5 5	max = 5


use Cwd qw();
my $CurrentDirectory = Cwd::cwd();
my $path = $CurrentDirectory;
print "path = $path\n";

use List::Util qw(min max);


my $query_file = "${path}/query_1";
my $target_file = "${path}/target_1";
my $query_position = "${path}/position_query_1";
my $target_position = "${path}/position_target_1";
my $recordq;
my @arrfilenameq;
my $q=0;
my $recordt;
my @arrfilenamet;
my $t=0;
my @arrfilenamea;
my $recorda;
my $a=0;
my $recordb;
my @arrfilenameb;
my $b=0;
my $start_pointt;
my @EndTarget;
my @EndQuery;
my @cycle_within_same_querypos;

my $end_query_range;
my $ori_query;
my $end_target_range;

my $get_oriquery;
my $lengthQuery;
my $BackOriQuery;
my $linesOutput = 0 ;
open (READQUERY, "$query_file") || die "couldn't open the file ($query_file)!";
while ($recordq = <READQUERY>){
 $arrfilenameq[$q] = substr($recordq,0,length($recordq)-1);
 $q++;
}
close(READQUERY);

open (READTARGET, "$target_file") || die "couldn't open the file ($target_file)!";
while ($recordt = <READTARGET>){
 $arrfilenamet[$t] = substr($recordt,0,length($recordt)-1);
 $t++;
}
close(READTARGET);

open (READPOSQUERY, "$query_position") || die "couldn't open the file ($query_position)!";
while ($recorda = <READPOSQUERY>){
$arrfilenamea[$a] = substr($recorda,0,length($recorda)-1);
$a++;
}
close(READPOSQUERY);

open (READPOSTARGET, "$target_position") || die "couldn't open the file ($target_position)!";
while ($recordb = <READPOSTARGET>){
$arrfilenameb[$b] = substr($recordb,0,length($recordb)-1);
$b++;
}
close(READPOSTARGET);


open (OUTPUT, ">${path}/output");

my $i;
my $j;
my $u;
for ($i=0; $i<scalar @arrfilenameq; $i++) { 

my $target = $arrfilenamet[$i];
my $start_point_query = $arrfilenamea[$i];
my $query = $arrfilenameq[$i];

if ($arrfilenamea[$i] eq '0') {

my @cycle_within_same_querypos = ();
my @everyelement = ();
my @EndTarget = ();
my @EndQuery =();


} else {}


my @len_target = split //, $target ; 
my $length_target = scalar @len_target;


my $split_pos_target = $arrfilenameb[$i];
my @after_split_position = split / /, $split_pos_target ; 
my @split_position = @after_split_position;

#each position in the array target i.e 0 9 18 48
foreach ($j=0; $j<scalar @split_position; $j++) {
my $start_point_target = $split_position[$j];
my @match_target = @_;
my @match_query = @_;
my @start_point_target = @_;
my @start_point_counter = @_;
my $counter = 1;
my @start_point_query = @_;

	for ($u=0; $u<$length_target;$u++) {
	
 	if(substr($query,$start_point_query,$counter) eq substr($target,$start_point_target,$counter)) {
  		push (@match_query,substr($query,$start_point_query,$counter));
  		push (@match_target,substr($target,$start_point_target,$counter));
  		push (@start_point_query,$start_point_target);
  		push (@start_point_target,$start_point_target);
  		push (@start_point_counter,$counter);
  		$counter++;
  
  		}
	 	else { 
 		}
}

my $size = (scalar @match_target) - 1;

#get the total number of match nts between query and target
my $total_sequence_target_match = $match_target[$size];
my $LengthTotalSeqTargetMatch = length($total_sequence_target_match);
my $size_pointt = (scalar @start_point_target) - 1;
$start_pointt = $start_point_target[$size_pointt];
my $size_counter = (scalar @start_point_counter) - 1;
my $last_counter = $start_point_counter[$size_counter];
$end_query_range = $start_point_query+$LengthTotalSeqTargetMatch;
$end_target_range = $start_pointt+$LengthTotalSeqTargetMatch;
$get_oriquery = reverse($query);
$ori_query = complement($get_oriquery);
$lengthQuery = length($query);
$BackOriQuery = $lengthQuery-$LengthTotalSeqTargetMatch;
my @lo_coun = @_;
push (@lo_coun,$counter);
my $max_value = max(@lo_coun);
my $match_range = $max_value-1;


my @everyelement = ();

push (@everyelement,($query,',', $target,',',$total_sequence_target_match,',', $start_pointt,',', $end_target_range,',',$start_point_query,',',$end_query_range,',','Range=',$match_range,';'));
push (@cycle_within_same_querypos,$match_range);
push (@EndTarget, $end_target_range);
push (@EndQuery, $end_query_range) ;
}


my $max_cycle_within_same_querypos = max @cycle_within_same_querypos;
my $numelements = @cycle_within_same_querypos;

if ($numelements == 1) {
}

else {
my $LastTarget = $EndTarget[-1];
my $SecondLastTarget = $EndTarget[-2];
my $LastQuery = $EndQuery[-1];
my $SecondLastQuery = $EndQuery[-2];
print OUTPUT "$ori_query\t$target\t$start_pointt\t$end_target_range\t$start_point_query\t$end_query_range\n";
}
}
my $linesScore0 = 0;
my $NoOfLinesScore0 = "${path}/output";
open (OUTPUTFINALSCORE, ">${path}/FinalScoreFalseBinding.txt");
open (FILESCORE, $NoOfLinesScore0) or die "Can't open '$NoOfLinesScore0'";
$linesScore0++ while (<FILESCORE>);
close FILESCORE;


#So to get the total score: each line in false binding sites (filename: output) is given score 1 and 
#each lines in file Score0 is given score -1 (due to the same redundancy, where its intended binding but found by false binding script)
#Therefore  total score for each round = lines output -(minus) lines score
my $NoOfLinesOutput = "${path}/output";

open (FILEOUTPUT, $NoOfLinesOutput) or die "Can't open '$NoOfLinesOutput'";
$linesOutput++ while (<FILEOUTPUT>);
close FILEOUTPUT;

my $TotalPenaltyForEachRound = $linesOutput-$linesScore0;

print OUTPUTFINALSCORE "$TotalPenaltyForEachRound\n";

close OUTPUT;
close OUTPUTFINALSCORE;


sub complement {
    $_[0] =~ y/CGATcgat/GCTAgcta/;
    return $_[0];
}






