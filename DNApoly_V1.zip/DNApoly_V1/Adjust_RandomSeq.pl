#!/usr/bin/perl
use warnings;
use strict;


use Cwd qw();
my $CurrentDirectory = Cwd::cwd();
my $path = $CurrentDirectory;



open (READ_SQUARETYPE, "${path}/SquareType.txt") || die "couldn't open the file (${path}/SquareType.txt)!";  
#open THEFILE, "<filename.txt";
my $first_line = <READ_SQUARETYPE>;
my @extractWithoutNewline = split(/\n/, $first_line);
close READ_SQUARETYPE;
my $SquareType = $extractWithoutNewline[0];
print "SquareType= --$SquareType---\n";



my $dsg_output = "${path}/RandomSeq.txt";
my $record ;
my @arrfilename;
my $count = 0;
my $DefSeqFilename = "${path}/${SquareType}DefineSeq.txt";
my $recordDef;
my $countDef = 0;
my @arrfilenameDef;




# read raw seq from DSG
open (READFILES, "$dsg_output") || die "couldn't open the file ($dsg_output)!";
while ($record = <READFILES>){
 $arrfilename[$count] = substr($record,0,length($record)-1);
 $count++; 
}
close(READFILES);

# Read DefineFile
open (READDEF, "$DefSeqFilename") || die "couldn't open the file ($DefSeqFilename)!";
while ($recordDef = <READDEF>){
 $arrfilenameDef[$countDef] = substr($recordDef,0,length($recordDef)-1);
 $countDef++; 
}
close(READDEF);

open (TEMPO_SEQ, ">${path}/Tempo_seq.txt");

# Extract DSGseq with specified length in defineSeq.txt
foreach (my $s=0; $s<$count; $s++) {
my $SPlus1 = $s+1;
 		foreach (my $d=0; $d<$countDef; $d++) {
 		my $arrayDef = $arrfilenameDef[$d];
		my @colDef = split('	', $arrayDef);
			if($SPlus1 == $colDef[0]) {
			my $SeqLength = $colDef[1];
			my $ExtractSeqDefLength =  substr ($arrfilename[$s],0,$SeqLength);
			print TEMPO_SEQ "$ExtractSeqDefLength\n";
			$d=$countDef;
			}
 		}
}
close(TEMPO_SEQ);


my $Tempo = "${path}/Tempo_seq.txt";
my @arrTempo;
my $recordT;
my $t = 0;
my $countTempo = 0;
my $Seqnt;

# Read seq with the specified length
open (READTEMPO, "$Tempo") || die "couldn't open the file ($Tempo)!";
while ($recordT = <READTEMPO>){
 $arrTempo[$countTempo] = substr($recordT,0,length($recordT)-1);
 $countTempo++; 
}
close(READTEMPO);

open (SEQ_AFTER_ADJUSTCOMPLEM, ">${path}/UnOptimized_Seq.txt");

foreach (my $t=0; $t<$countTempo; $t++) {
my $Seqnt = $arrTempo[$t];
my $tPlus1 = $t+1;
		foreach (my $e=0; $e<$countDef; $e++) {
		my $arrayDef = $arrfilenameDef[$e];
		my @colDef = split('	', $arrayDef);
				if($tPlus1 == $colDef[0] ) {
				
				my $CurrentSeqStartPos = $colDef[2];
				my $CurrentSeqEndPos = $colDef[3];
				my $PairSeqNo = $colDef[4];
				my $PairSeqStartPos = $colDef[5];
				my $PairSeqEndPos = $colDef[6];
				
				## check if NIl exist, move to next cz NIl cannot extract position
				if ($CurrentSeqStartPos =~ /^[+-]?\d+$/ ) {
				my $PairSeqNoMinus1 = $PairSeqNo-1;
				my $ComplemPairSegment;
				my $revComplemPairSegment;
				#print "1. SeqNo $tPlus1: $Seqnt\n";
				#print "2. Pair $PairSeqNo $arrTempo[$PairSeqNoMinus1]\n";
				#print "3. $tPlus1 $colDef[2] $colDef[3]; $PairSeqNo $PairSeqStartPos $PairSeqEndPos\n";
				my $DifferencesNtsPairPlus1 = $PairSeqEndPos-$PairSeqStartPos+1;
				my $Pairsegment =  substr ($arrTempo[$PairSeqNoMinus1],$PairSeqStartPos-1,$DifferencesNtsPairPlus1);
				#print "5. $arrTempo[$PairSeqNoMinus1],$PairSeqStartPos-1,$DifferencesNtsPairPlus1  === $Pairsegment\n";
				my $revcomplemdsegment = reverse_complement($Pairsegment);
				#print "6. revcomplem = $revcomplemdsegment--\n";
				my $DifferencesNts = $colDef[3]-$colDef[2];
				my $DifferencesNtsPlus1 = $DifferencesNts+1;
				my $ColDef2Minus1 = $colDef[2]-1;
				# To replace current strong position
				substr($Seqnt, $ColDef2Minus1, $DifferencesNtsPlus1) = "$revcomplemdsegment";
				#print "8. After replaced: New Seq$tPlus1 $Seqnt\n\n";
				#my $Tempo_newseq $Seqnt;
				}
				}
		}
		print SEQ_AFTER_ADJUSTCOMPLEM "$Seqnt\n";
}

close(SEQ_AFTER_ADJUSTCOMPLEM);

sub reverse_complement {
        my $dna = shift;
	# reverse the DNA sequence
        my $revcomp = reverse($dna);
	# complement the reversed DNA sequence
        $revcomp =~ tr/ACGTacgt/TGCAtgca/;
        return $revcomp;
}


unlink glob ("${path}/Tempo_seq.txt");






