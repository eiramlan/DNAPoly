#!/usr/bin/perl
use strict;
use warnings;

use Cwd qw();
my $CurrentDirectory = Cwd::cwd();
my $path = $CurrentDirectory;


my $query_file = "${path}/query";
my $target_file = "${path}/target";
my $query_position = "${path}/position_query";
my $target_position = "${path}/position_target";
my $recordq;
my @arrfilenameq;
my $q = 0;
my @arrfilenamet;
my $t = 0;
my $recordt;
my @arrfilenamea;
my $recorda;
my $a=0;
my $recordb;
my @arrfilenameb;
my $b=0;

open (READQUERY, "$query_file") || die "couldn't open the file ($query_file)!";
while ($recordq = <READQUERY>){
 $arrfilenameq[$q] = substr($recordq,0,length($recordq)-1);
 $q++;
}
close(READQUERY);

open (READTARGET, "$target_file") || die "couldn't open the file ($target_file)!";
while ($recordt = <READTARGET>){
 $arrfilenamet[$t] = substr($recordt,0,length($recordt)-1);
 $t++;
}
close(READTARGET);

open (READPOSQUERY, "$query_position") || die "couldn't open the file ($query_position)!";
while ($recorda = <READPOSQUERY>){
$arrfilenamea[$a] = substr($recorda,0,length($recorda)-1);
$a++;
}
close(READPOSQUERY);


open (READPOSTARGET, "$target_position") || die "couldn't open the file ($target_position)!";
while ($recordb = <READPOSTARGET>){
$arrfilenameb[$b] = substr($recordb,0,length($recordb)-1);
$b++;
}
close(READPOSTARGET);

open (QUERY_SEQ, ">${path}/query_1");
open (TARGET_SEQ, ">${path}/target_1");
open (POS_QUERY, ">${path}/position_query_1");
open (POS_TARGET, ">${path}/position_target_1");

for (my $i=0; $i<scalar @arrfilenameb; $i++) {

if ($arrfilenameb[$i] ne '') {

print TARGET_SEQ "$arrfilenamet[$i]\n";
print QUERY_SEQ "$arrfilenameq[$i]\n";
print POS_QUERY "$arrfilenamea[$i]\n";
print POS_TARGET "$arrfilenameb[$i]\n";
}
}


close QUERY_SEQ ;
close TARGET_SEQ ;
close POS_QUERY ;
close POS_TARGET ;

